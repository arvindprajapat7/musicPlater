const accessKey = "vvzCVgO763V3jzKxBZq8lEXkHeu-y7RZEsdID3_PPXc";
let inputData = document.querySelector('#inputSearch');
let searchBtn = document.querySelector('#searchBtn');
let searchResutls = document.querySelector('.searchResutls');
let loadMore = document.querySelector('#loadMore');
let formEl = document.querySelector('form');
let page = 0; 
async function searchImage(){
    let url = `https://api.unsplash.com/search/photos?page=${page}&query=${inputData.value}&client_id=${accessKey}`
    const response = await fetch(url);
    const data  = await response.json();

    let results = data.results;
    console.log(results);
    results.map((item)=>{
        let cre_item = document.createElement('div');
        cre_item.setAttribute('class','item');
        let cre_img = document.createElement('IMG');
        cre_img.src = item.urls.small;
        let userInfo = document.createElement('div');
        userInfo.setAttribute('class', 'userInfo');
        let profileImgDiv = document.createElement('div');
        profileImgDiv.setAttribute('class','profileImg');
        let profileImg = document.createElement('IMG');
        profileImg.src = item.user.profile_image.small;
        cre_item.appendChild(cre_img);
            searchResutls.append(cre_item)
        profileImgDiv.appendChild(profileImg);
        userInfo.appendChild(profileImgDiv);
        cre_item.appendChild(userInfo);
        
        let  userNameDiv = document.createElement('div');
        userNameDiv.setAttribute('class', 'userName');
        let cre_a = document.createElement('a');
        cre_a.setAttribute('href',item.user.links.html);
        cre_a.setAttribute('target','_blank');
        cre_a.innerHTML = item.user.first_name;
        userNameDiv.appendChild(cre_a);

        userInfo.appendChild(userNameDiv);
    })
    if(inputData.value== ""){
        // alert('Please enter something')
    }else{
        page++;
        if(page>0){
            loadMore.style.display="block";
        }
        console.log(page)
    }
}
loadMore.addEventListener('click', function(){
    searchImage();
});
formEl.addEventListener('submit', function(e){
    e.preventDefault();
        page == 0 ; 
        searchResutls.innerHTML = "";
        searchImage(); 
} )

