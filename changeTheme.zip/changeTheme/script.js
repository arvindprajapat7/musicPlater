let colorList = document.querySelector('.colorList');

function randomColor(){
    
    
    
    
}
for(let i = 0; i<500; i++){
    let cre_li = document.createElement('li');
    let color = "#"; 
    for(let i=0; i<6; i++){
        let hex = '0123456789ABCDEF';
        color += hex[Math.floor(Math.random()*16)];
    }
    // console.log(color);
        cre_li.style.backgroundColor= color;  
        cre_li.setAttribute('onclick', 'changeBg(this)')
        cre_li.setAttribute('bg-data', color)
        colorList.appendChild(cre_li);
}


function changeBg(e){
    // console.log(document.querySelectorAll('li'))
    document.querySelectorAll('li').forEach((item)=>{
        item.classList.remove('active')
    })
    document.body.style.background = e.getAttribute('bg-data');

    e.classList.add('active');
    // console.log(e.getAttribute('bg-data'));
}